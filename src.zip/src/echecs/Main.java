package echecs;

class Main {

    private static Echequier echequier = new Echequier(8);
    public static void main(String[] args) {
        echequier.partie();
        
    }
}